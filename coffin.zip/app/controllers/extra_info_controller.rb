class ExtraInfoController < ApplicationController

  def edit

  end

end
