class DashboardController < ApplicationController
  before_action :require_reguser

  def index
  end

end
