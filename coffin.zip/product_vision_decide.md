# Product Vision

###	What are the three most important features?
Deadman’s Switch
Contacting loved ones.
Allow access to deceased’s data.
###	How would you prioritize them?
Same order as above.
