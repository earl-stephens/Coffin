# Product Vision – Brainstorm
###	What would an MVP (minimum viable product) look like? If your team needed to ship features every evening to prove value to an investor, what would you work on and in what order?
List of actions to complete when a person dies.  Deadman’s switch.  
###	What would set you apart during demo night?
The concept of the app itself would set us apart.  
###	What intimidates you but would be amazing to pull off?
Twilio.  Mobile formatting.
###	How should your users experience the app? Desktop, mobile, native app?
Mobile.  (Create it in desktop first, then migrate to mobile)
###	What features or technology choices would spark interesting discussions during job interviews?
Security of data.  SOA - Java?  Python?
###	Would you use this product? If not, what is it missing?
Yes.  If we can add in gamification or other fun stuff, that would be even better.
